#from https://www.powershellgallery.com/packages/LabBuilder/0.7.9.953/Content/dsclibrary%5CMEMBER_ADFS.DSC.ps1
#.Title 
#    MEMBER_ADFS 
#.Desription 
 #   Builds an ADFS Server using WID. 
#.Parameters: 

Configuration MEMBER_ADFS
{
    Node localhost
    {
        WindowsFeature WIDInstall
        {
            Ensure = "Present"
            Name = "Windows-Internal-Database"
        }

        WindowsFeature ADFSInstall
        {
            Ensure = "Present"
            Name = "ADFS-Federation"
            DependsOn = "[WindowsFeature]WIDInstall"
        }
    }
}

